//
//  ViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    :C0668050
//  Name        :SINGAMPALLI SAGAR DEEPAK

import UIKit

class SmsAndPhoneCallViewController: UIViewController {

    @IBOutlet weak var phonenumber: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func sendText(_ sender: UIButton) {
      //  if (SmsAndPhoneCallViewController.canSendText) {
        _ = messageComposeViewController(controller: )
          controller.copy = "Message Body"
           controller.recipients = [phonenumber.text]
           controller.messageComposeDelegate = self
           self.present(controller, animated: true, completion: nil)
        }
    }

    func messageComposeViewController(controller: SmsAndPhoneCallViewController!) {
        ... handle sms screen actions
       self.dismiss(animated: true, completion: nil)
}
 override func viewWillDisappear(_ animated: Bool) {
  self.navigationController?.isNavigationBarHidden = false



func didReceiveMemoryWarning() {
    
        // Dispose of any resources that can be recreated.
    }




